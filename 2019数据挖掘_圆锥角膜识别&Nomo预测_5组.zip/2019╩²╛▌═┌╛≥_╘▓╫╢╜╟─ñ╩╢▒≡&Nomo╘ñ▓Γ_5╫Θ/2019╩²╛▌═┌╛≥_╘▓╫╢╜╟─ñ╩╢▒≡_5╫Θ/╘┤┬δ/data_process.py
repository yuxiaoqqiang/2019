# -*- coding: utf-8 -*-
import xlrd
import xlwt
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn import svm
from sklearn import naive_bayes
from sklearn.naive_bayes import MultinomialNB
from sklearn import tree
import sklearn.neural_network as sk_nn
import sklearn.model_selection as sk_model_selection
from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import  AdaBoostClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis
from sklearn import preprocessing
from sklearn.metrics import classification_report
from imblearn.over_sampling import SMOTE
from pandas_ml import ConfusionMatrix
from sklearn.model_selection import StratifiedKFold

# 禁用科学输入法
np.set_printoptions(suppress=True)
# 设置文件路径
path = "D:/train.xlsx"
picpath = "D:/python_project/pic"
filepath = "D:/python_project/result.txt"
# 设置画布格式
sns.set_style('darkgrid')

# 创建文件夹，用于输出图像
def mkdir(path):
    # 引入模块
    # 判断路径是否存在
    # 存在     True
    # 不存在   False
    isExists = os.path.exists(path)
    # 判断结果
    if not isExists:
        # 如果不存在则创建目录
        # 创建目录操作函数
        os.makedirs(path)
        # print(path + ' 创建成功')
        return True
    else:
        # 如果目录存在则不创建，并提示目录已存在
        # print(path + ' 目录已存在')
        return False


def oversampling_data(X, y):
    sample_solver = SMOTE(random_state=0)
    X_sample, y_sample = sample_solver.fit_sample(X, y)  # 从原始的训练集采出样本，用来训练模型
    return  np.array(X_sample), np.array(y_sample).reshape(
        len(y_sample))

def load_and_analyse_data(X, y):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)
    # ----------------------采样-------------------
    sample_solver = SMOTE(random_state=0)
    X_sample, y_sample = sample_solver.fit_sample(X_train, y_train)  # 从原始的训练集采出样本，用来训练模型
    return np.array(X_train), np.array(y_train).reshape(len(y_train)), np.array(X_test), np.array(y_test).reshape(len(y_test)), np.array(X_sample), np.array(y_sample).reshape(
        len(y_sample))

def accuracy(test_labels, pred_labels):
  correct1 = np.sum(test_labels == pred_labels)
  n = len(test_labels)
  return float(correct1)/n

def trainGBDT(trainx, trainy,
              # X_dev, y_dev,
              # X_test, y_test
              ifoversampling):
    bestGBDT = GradientBoostingClassifier(
        n_estimators=180,
        max_depth=5,
        min_samples_split=180,
        min_samples_leaf=40,
        learning_rate=0.1, max_features='sqrt', random_state=10)
    kfold = StratifiedKFold(n_splits=10, shuffle=True, random_state=10)
    score1 = 0
    report = None
    for train, test in kfold.split(trainx, trainy):
        x_sample, y_sample = oversampling_data(trainx[train], trainy[train])
        if ifoversampling:
            bestGBDT.fit(x_sample, y_sample)
        else:
            bestGBDT.fit(trainx[train], trainy[train])
        prey = bestGBDT.predict(trainx[test])
        if score1 == 0:
            report = classification_report(prey, trainy[test])
        score1 += np.array(accuracy(prey, trainy[test]))
    print("final result:", score1 / 10)
    print(report)

    # param_test1 = {
    #     'n_estimators': range(180, 201, 15),
    #     'min_samples_split': range(160, 181, 10)
    #     }
    # bestGBDT = GridSearchCV(estimator=GradientBoostingClassifier(
    #     # n_estimators=170,
    #     max_depth=5,
    #     # min_samples_split=150,
    #     min_samples_leaf=40,
    #     learning_rate=0.1, max_features='sqrt', random_state=10), param_grid=param_test1, scoring=None, iid=False, cv=10)
    # bestGBDT.fit(trainx, trainy)
    # print(bestGBDT.best_params_)
    # print('GBDT在采样数据上的性能表现：')
    # print(bestGBDT.score(X_dev, y_dev))
    # y_dev_pre = bestGBDT.predict(X_dev)
    # print(classification_report(y_dev, y_dev_pre))
    # print('GBDT的性能表现：')
    # print(bestGBDT.score(X_test, y_test))
    # y_pre = bestGBDT.predict(X_test)
    # print(classification_report(y_test, y_pre))
    # model = gsearch1.best_params_
    # print(gsearch1.best_params_)

    # model = GradientBoostingClassifier(n_estimators=190, max_depth=4, min_samples_split=150, min_samples_leaf=60)
    # accs = sk_model_selection.cross_val_score(model, trainx, trainy, scoring=None, cv=5, n_jobs=1)
    # print('GBDT5折交叉验证结果: ', accs)
    # print('GBDT5折交叉验证结果平均值: %.4f' % np.mean(accs))

def trainRandomForest(trainx, trainy,
                      # X_dev, y_dev,
                      # X_test, y_test
                      ifoversampling):
    RF = RandomForestClassifier(n_estimators=18)
    kfold = StratifiedKFold(n_splits=10, shuffle=True, random_state=10)
    score1 = 0
    report = None
    for train, test in kfold.split(trainx, trainy):
        x_sample, y_sample = oversampling_data(trainx[train], trainy[train])
        if ifoversampling:
            RF.fit(x_sample, y_sample)
        else:
            RF.fit(trainx[train], trainy[train])
        prey = RF.predict(trainx[test])
        if score1 == 0:
            report = classification_report(prey, trainy[test])
        score1 += np.array(accuracy(prey, trainy[test]))
    print("final result:", score1 / 10)
    print(report)


    # param_test1 = {
    #     'n_estimators': range(15, 20)
    # }
    # bestRF = GridSearchCV(RF, param_test1, scoring='accuracy', cv=10, n_jobs=4)
    # bestRF.fit(trainx, trainy)
    # print(bestRF.best_params_)
    # print('RF在采样数据上的性能表现：')
    # print(bestRF.score(X_dev, y_dev))
    # y_dev_pre = bestRF.predict(X_dev)
    # print(classification_report(y_dev, y_dev_pre))
    # print('RF的性能表现：')
    # print(bestRF.score(X_test, y_test))
    # y_pre = bestRF.predict(X_test)
    # print(classification_report(y_test, y_pre))

    # model = RandomForestClassifier(n_estimators=8)
    # accs = sk_model_selection.cross_val_score(model, trainx, trainy, scoring=None, cv=5, n_jobs=1)
    # print('RandomForest5折交叉验证结果: ', accs)
    # print('RandomForest5折交叉验证结果平均值: %.4f' % np.mean(accs))

def trainSvm(trainx, trainy,
             # X_dev, y_dev,
             # X_test, y_test
             ifoversampling):
    svc = svm.SVC(C=0.1, kernel='linear')
    kfold = StratifiedKFold(n_splits=10, shuffle=True, random_state=10)
    score1 = 0
    report = None
    for train, test in kfold.split(trainx, trainy):
        x_sample, y_sample = oversampling_data(trainx[train], trainy[train])
        if ifoversampling:
            svc.fit(x_sample, y_sample)
        else:
            svc.fit(trainx[train], trainy[train])
        prey = svc.predict(trainx[test])
        if score1 == 0:
            report = classification_report(prey, trainy[test])
        score1 += np.array(accuracy(prey, trainy[test]))
    print("final result:", score1 / 10)
    print(report)
    # parameters ={
    #         'C': [0.01, 0.1, 0.3, 0.5],
    #         'kernel': ['linear']
    #     }
    # training
    # bestsvc = GridSearchCV(svc, parameters, scoring='accuracy', cv=10, n_jobs=4)
    # accs = sk_model_selection.cross_val_score(bestsvc, trainx, trainy, scoring='accuracy', cv=10, n_jobs=1)
    # print('Svm 10折交叉验证结果: ', accs)
    # print('Svm 10折交叉验证结果平均值: %.4f' % np.mean(accs))
    # y_pre = bestsvc.predict(trainx)
    # print(classification_report(trainy, y_pre))
    # bestsvc.fit(trainx, trainy)
    # print(bestsvc.best_params_)
    # print('Svm在采样数据上的性能表现：')
    # print(bestsvc.score(X_dev, y_dev))
    # y_dev_pre = bestsvc.predict(X_dev)
    # print(classification_report(y_dev, y_dev_pre))
    # print('Svm的性能表现：')
    # print(bestsvc.score(X_test, y_test))
    # y_pre = bestsvc.predict(X_test)
    # print(classification_report(y_test, y_pre))

    # cls = svm.SVC(kernel='linear', C=0.5)
    # cross_val_score(cls, train_X, train_y, cv=5, scoring='accuracy')
    # cls.fit(train_X, train_y)
    # accs = sk_model_selection.cross_val_score(cls, trainx, trainy, scoring=None, cv=5, n_jobs=1)
    # print('Svm5折交叉验证结果: ', accs)
    # print('Svm5折交叉验证结果平均值: %.4f' % np.mean(accs))



def trainKnn(trainx, trainy,
             # X_dev, y_dev,
             # X_test, y_test
             ifoversampling):
    knn = KNeighborsClassifier(n_neighbors=8)
    kfold = StratifiedKFold(n_splits=10, shuffle=True, random_state=10)
    score1 = 0
    report = None
    for train, test in kfold.split(trainx, trainy):
        x_sample, y_sample = oversampling_data(trainx[train], trainy[train])
        if ifoversampling:
            knn.fit(x_sample, y_sample)
        else:
            knn.fit(trainx[train], trainy[train])
        prey = knn.predict(trainx[test])
        if score1 == 0:
            report = classification_report(prey, trainy[test])
        score1 += np.array(accuracy(prey, trainy[test]))
    print("final result:", score1 / 10)
    print(report)
    # param_test1 = {
    #     'n_neighbors': range(1, 11)
    #     }
    # best_knn = GridSearchCV(knn, param_test1, scoring='accuracy', cv=10, n_jobs=4)
    # score = cross_val_score(GridSearchCV(knn, param_test1, cv=10), trainx, trainy, cv=10, scoring='accuracy')
    # best_knn.fit(trainx, trainy)
    # print(best_knn.best_params_)
    # print('Knn在采样数据上的性能表现：')
    # print(best_knn.score(X_dev, y_dev))
    # y_dev_pre = best_knn.predict(X_dev)
    # print(classification_report(y_dev, y_dev_pre))
    # print('Knn的性能表现：')
    # print(score)
    # print(np.mean(score))
    # print(best_knn.score(X_test, y_test))
    # y_pre = best_knn.predict(X_test)
    # print(classification_report(y_test, y_pre))
    # confusion_matrix = ConfusionMatrix(y_test, y_pre)
    # confusion_matrix.print_stats()

    # k_range = range(1, 11)
    # # 用来放每个模型的结果值
    # cv_scores = []
    # for n in k_range:
    #     # knn模型，这里一个超参数可以做预测，当多个超参数时需要使用另一种方法GridSearchCV
    #     knn = KNeighborsClassifier(n)
    #     # cv：选择每次测试折数  accuracy：评价指标是准确度,可以省略使用默认值
    #     scores = cross_val_score(knn, trainx, trainy, cv=10, scoring='accuracy')
    #     cv_scores.append(scores.mean())
    # 可视化数据,通过图像选择最好的参数
    # plt.plot(k_range, cv_scores)
    # plt.xlabel('K')
    # plt.ylabel('Accuracy')
    # plt.show()
    # 选择最优K值，计算最佳结果
    # knn = KNeighborsClassifier()
    # param_test1 = {
    #     'n_neighbors': range(1, 2)
    #     }
    #
    # best_knn = GridSearchCV(knn, param_test1, scoring='accuracy', cv=10, n_jobs=1)
    # # best_knn = KNeighborsClassifier(n_neighbors=cv_scores.index(max(cv_scores))+1)# 选择最优的K传入模型
    # best_knn.fit(trainx, trainy)
    # # param = ['f1_micro',
    # #          'accuracy']
    # # # for p in param:
    # # #     result = []
    # acc = sk_model_selection.cross_val_score(best_knn, trainx, trainy, scoring='accuracy', cv=10, n_jobs=1)
    # print('Knn ' + 'acc' + ' 10折交叉验证结果: ', acc)
    # print('Knn ' + 'acc' + ' 10折交叉验证结果平均值: %.4f' % np.mean(acc))
    #
    # f1_micro = sk_model_selection.cross_val_score(best_knn, trainx, trainy, scoring='f1_micro', cv=10, n_jobs=1)
    # print('Knn ' + 'f1_micro' + ' 10折交叉验证结果: ', f1_micro)
    # print('Knn ' + 'f1_micro' + ' 10折交叉验证结果平均值: %.4f' % np.mean(f1_micro))


    # print('Train KNN score: %.4f' % best_knn.score(train_X, train_y))
    # print('Test KNN score: %.4f' % best_knn.score(test_X, test_y))



def main():
    # 打开execl
    workbook = xlrd.open_workbook(path)
    # 输出execl
    book = xlwt.Workbook(encoding='utf-8', style_compression=0)
    # 输出Excel文件中所有sheet的名字
    # print(workbook.sheet_names())

    # 用于保存用于train及test的数据
    x = []
    y = []

    # 遍历3个标签
    for k in range(3):
        # 根据sheet索引或者名称获取sheet内容
        Data_sheet = workbook.sheets()[k]  # 通过索引获取
        # Data_sheet = workbook.sheet_by_index(0)  # 通过索引获取
        # Data_sheet = workbook.sheet_by_name(u'名称')  # 通过名称获取

        # 用于输出excel
        sheet = book.add_sheet(Data_sheet.name, cell_overwrite_ok=True)

        rowNum = Data_sheet.nrows  # sheet行数
        colNum = Data_sheet.ncols  # sheet列数

        # 获取所有单元格的内容，Left为0，Right为1，None和空值设置为-999，所有数据均为str或float类型
        # ctype:0 empty,1 string, 2 number, 3 date, 4 boolean, 5 error
        list = []
        tx = []
        for i in range(rowNum):
            rowlist = []
            for j in range(colNum):
                if Data_sheet.cell(i, j).ctype == 0:
                    sheet.write(i, j, float(-999))
                    rowlist.append(float(-999))
                elif i == 0 and Data_sheet.cell(i, j).ctype == 1:
                    rowlist.append(Data_sheet.cell_value(i, j).strip())
                    sheet.write(i, j, Data_sheet.cell_value(i, j).strip())
                elif i != 0 and Data_sheet.cell(i, j).ctype == 1:
                    if Data_sheet.cell_value(i, j).strip() == "Left":
                        sheet.write(i, j, float(0))
                        rowlist.append(float(0))
                    elif Data_sheet.cell_value(i, j).strip() == "Right":
                        sheet.write(i, j, float(1))
                        rowlist.append(float(1))
                    elif Data_sheet.cell_value(i, j).strip() == "None":
                        sheet.write(i, j, float(-999))
                        rowlist.append(float(-999))
                    else:
                        a = int(Data_sheet.cell_value(i, j).find('?'))
                        b = Data_sheet.cell_value(i, j)[0: a].strip()
                        sheet.write(i, j, float(b))
                        rowlist.append(float(b))
                else:
                    rowlist.append(float(Data_sheet.cell_value(i, j)))
                    sheet.write(i, j, float(Data_sheet.cell_value(i, j)))
            list.append(rowlist)

        # 打印特征值的直方图
        # showlist = []
        # name = ""
        # m = 0
        # for j in range(colNum):
        #     for i in range(rowNum):
        #         if i == 0:
        #             name = list[i][j]
        #         else:
        #             showlist.append(list[i][j])
        #     mkdir(picpath + "/" + name)
        #     for m in range(rowNum):
        #         if showlist[m] != 0:
        #             break
        #         if m == rowNum - 2:
        #             break
        #     if m == rowNum - 2:
        #         showlist = []
        #         m = 0
        #         continue
        #     fig = plt.figure(figsize=(4, 4))
        #     sns.distplot(showlist, color='#ff8000')
        #     # plt.show()
        #     fig.savefig(picpath + "/" + name + "/" + Data_sheet.name + ".png")
        #     showlist = []
        #     m = 0
        #     plt.close()

        # 训练数据tx
        for i in range(rowNum):
            mark = 0
            for j in range(colNum):
                if i == 0:
                    # 去除第一行属性名
                    mark = 1
                    break
                else:
                    if j == 0 or j == 1 or j == 2 or list[0][j] == "PTI 0mm" or list[0][j] == "PTI 10mm" or list[0][j] == "CTSP 10mm":
                        # 去除无效数据(编号，出生年，就医年，None或空)
                        continue
                    else:
                        tx.append(list[i][j])
            if mark != 0:
                continue
            x.append(tx)
            y.append(k)
            tx = []
    # 数据格式转化，list to array
    trainx = np.array(x, dtype=float)
    trainy = np.array(y, dtype=int)
    # 重抽样
    # XX_train, YY_train, X_test, y_test, X_sample, y_sample = load_and_analyse_data(trainx, trainy)

    # X_sample, y_sample = oversampling_data(trainx, trainy)

    # Oversampling
    # X_train, X_dev, y_train, y_dev = train_test_split(X_sample, y_sample, test_size=0.3, random_state=0)
    # No Oversampling
    # Xx_train, Xx_dev, yy_train, yy_dev = train_test_split(XX_train, YY_train, test_size=0.3, random_state=0)
    # newtrainx = preprocessing.scale(trainx)
    # KNN Classifier
    print("KNN Oversampling")
    trainKnn(trainx, trainy,
             # X_dev, y_dev,
             # X_test, y_test
             True)
    print("KNN No Oversampling")
    trainKnn(
            trainx, trainy,
             # Xx_dev, yy_dev,
             # X_test, y_test
            False)
    # SVM Classifier
    print("SVM Oversampling")
    trainSvm(trainx, trainy,
             # X_dev, y_dev,
             # X_test, y_test
             True)
    print("SVM No Oversampling")
    trainSvm(trainx, trainy,
             # Xx_dev, yy_dev,
             # X_test, y_test
             False)
    # Random Forest Classifier
    print("RF Oversampling")
    trainRandomForest(trainx, trainy,
                      # X_dev, y_dev,
                      # X_test, y_test
                      True)
    print("RF No Oversampling")
    trainRandomForest(trainx, trainy,
                      # Xx_dev, yy_dev,
                      # X_test, y_test
                      False)
    # GBDT(Gradient Boosting Decision Tree) Classifier
    print("GBDT Oversampling")
    trainGBDT(trainx, trainy,
              # X_dev, y_dev,
              # X_test, y_test
              True)
    print("GBDT No Oversampling")
    trainGBDT(trainx, trainy,
              # Xx_dev, yy_dev,
              # X_test, y_test
              False)

    # 之前的KNN模型
    # X_train, X_test, y_train, y_test = train_test_split(trainx, trainy, test_size=0.3)

    # knn = KNeighborsClassifier()
    # knn.fit(X_train, y_train)

    # x_cal = knn.predict(X_test)

    # m = 0
    # xx_cal = x_cal.tolist()
    # y_cal = y_test.tolist()

    # for i in range(0, len(xx_cal)):
    #     if xx_cal[i] == y_cal[i]:
    #         m = m + 1
    # print("KNN: " + str(float(m)/len(xx_cal)))

    # 保存到新的excel中
    # book.save(r'D:/newtrain.xls')

if __name__ == '__main__':
    print("Process Start")
    main()
    print("End")

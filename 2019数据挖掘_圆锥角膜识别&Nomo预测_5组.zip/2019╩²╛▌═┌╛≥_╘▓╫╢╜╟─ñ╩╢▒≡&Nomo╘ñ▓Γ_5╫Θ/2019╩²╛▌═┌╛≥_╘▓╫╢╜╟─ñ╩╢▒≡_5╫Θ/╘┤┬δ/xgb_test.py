import pandas as pd
import numpy as np
import xgboost as xgb
import lightgbm as lgb
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.linear_model import LogisticRegression, LogisticRegressionCV
from xgboost.sklearn import XGBClassifier
from pandas_ml import ConfusionMatrix 
from imblearn.over_sampling import SMOTE

#pos = pd.read_csv('newtrain_rawdata_1.csv', na_values = ' NaN', keep_default_na = True)
#neu = pd.read_csv('newtrain_s_rawdata_1.csv', na_values = ' NaN', keep_default_na = True)
#neg = pd.read_csv('newtrain_y_rawdata_1.csv', na_values = ' NaN', keep_default_na = True)

#pos["target"] = [0 for i in range(pos.shape[0])]
#neu["target"] = [1 for i in range(neu.shape[0])]
#neg["target"] = [2 for i in range(neg.shape[0])]
#train = pd.concat([pos, neu, neg], axis=0)#.dropna(thresh=15, axis=1)

train = pd.read_csv('train_1.csv', na_values = ' NaN', keep_default_na = True)

train = train.fillna(0)

#train = train.sample(frac=1)

#train.to_csv("train_999.csv")

kfold = StratifiedKFold(n_splits=10, shuffle=True, random_state=10)

predictor = [x for x in train.columns if x not in ["target", "ID", "ID1", "BirthD", "CTSP 10mm", "PTI 0mm", "PTI 10mm", "WFA Corea 9", "WFA Corea 12", "WFA Corea 15", "WFA Corea 18"]]



features = train[predictor].values 
labels = train["target"].values

from sklearn import preprocessing
min_max_scaler = preprocessing.StandardScaler()
features = min_max_scaler.fit_transform(features)

def accuracy(test_labels, pred_labels):
  correct1 = np.sum(test_labels == pred_labels) # 完全正确
  correct2 = np.sum(abs(test_labels-pred_labels) <= 5) # 近似正确
  n = len(test_labels)
  return [float(correct1)/n, float(correct2)/n]

score1 = 0



'''
for train, test in kfold.split(features, labels):
    clf = XGBClassifier(num_round = 10)
    xgb.train(features[train], labels[train])
    pred = clf.predict(features[test])
    score1 += np.array(accuracy(pred, labels[test]))
    print(np.array(accuracy(pred, labels[test])))
'''
param = {
#    'booster': 'gbtree',  
    'objective': 'multi:softmax',  # 多分类的问题 binary:logistic 
    'num_class': 3,        
#    'gamma': 0.005,                  # 用于控制是否后剪枝的参数,越大越保守，一般0.1、0.2这样子。
    'max_depth': 6,               # 构建树的深度，越大越容易过拟合
    'lambda': 1.0,                   # 控制模型复杂度的权重值的L2正则化项参数，参数越大，模型越不容易过拟合。
#    'subsample': 0.7,              # 随机采样训练样本
#    'colsample_bytree': 0.7,       # 生成树时进行的列采样
#    'min_child_weight': 3,
#    'silent': 1,                   # 设置成1则没有运行信息输出，最好是设置为0.
    'eta': 1.08,                  # 如同学习率
#    'seed': 1000,
#    'nthread': 4,                  # cpu 线程数
}

from xgboost import plot_importance
from matplotlib import pyplot as plt
plt.switch_backend('agg')
count = 0
for i in range(len(predictor)):
  print(i, predictor[i]) 
for train, test in kfold.split(features, labels):
    count += 1
    over_samples = SMOTE(random_state=1234) 
#    print("features shape:", features.shape, features)
#    print("inf index", np.where(features[train] >= np.finfo(np.float64).max))
#    over_samples_X, over_samples_y = over_samples.fit_sample(features[train], labels[train])
    over_samples_X = features[train]
    over_samples_y = labels[train]



    f_train = xgb.DMatrix(over_samples_X, label = over_samples_y)
    clf = xgb.train(param, f_train, num_boost_round = 100)
    pred = clf.predict(xgb.DMatrix(features[test]))


#    from sklearn import ensemble
#    clf = ensemble.GradientBoostingClassifier(        # n_estimators=170,
#        max_depth=5,
        # min_samples_split=150,
#        min_samples_leaf=40,
#        learning_rate=0.1, max_features='sqrt', random_state=10)
#    clf.fit(over_samples_X, over_samples_y)
#    pred = clf.predict(features[test])

    predicted_y = np.array(pred)
    right_y = np.array(labels[test])
    confusion_matrix = ConfusionMatrix(right_y, predicted_y)
    confusion_matrix.print_stats()
   
#    plot_importance(clf)
#    fig = plt.gcf()
#    fig.set_size_inches(10.5, 50.5)
#    fig.savefig("imp_" + str(count), dpi=100)
    print(pred)
    score1 += np.array(accuracy(pred, labels[test]))
    print(np.array(accuracy(pred, labels[test])))

print(score1/10)